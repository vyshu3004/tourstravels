package com.tourstravels.tourstravels.services.impl;

import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.io.IOException;
import java.lang.module.Configuration;


@Service
@RequiredArgsConstructor
public class EmailService {
    @Value("${spring.mail.username}")
    private String fromEmail;
    private final Configuration configuration;
    private final JavaMailSender javaMailSender;
    public void sendEmail(MailData mailData) throws IOException, TemplateException {
        var template = configuration.getTemplate(mailData.getTemplate() + ".ftl");
        var content = FreeMarkerTemplateUtils.processTemplateIntoString(template, mailData.getModel());

        MimeMessagePreparator mimeMessagePreparator = mimeMessage -> {
            var messageHelper = new MimeMessageHelper(mimeMessage, true);
            messageHelper.setFrom(fromEmail);
            messageHelper.setTo(mailData.getToEmail());
            messageHelper.setSubject(mailData.getSubject());
            messageHelper.setText(content, true);
        };
        javaMailSender.send(mimeMessagePreparator);
    }
}



