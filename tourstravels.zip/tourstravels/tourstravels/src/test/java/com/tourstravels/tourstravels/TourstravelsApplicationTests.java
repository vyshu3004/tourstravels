package com.tourstravels.tourstravels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourstravelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
